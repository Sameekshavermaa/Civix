package com.civix.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class MaintenanceChargeRequest {
    @NotBlank(message = "Charge month is required (YYYY-MM)")
    private String chargeMonth;

    @NotNull(message = "Base amount is required")
    @DecimalMin(value = "0.01", message = "Base amount must be positive")
    private BigDecimal baseAmount;

    private BigDecimal lateFee = BigDecimal.ZERO;
    private String description;

    @NotBlank(message = "Due date is required")
    private String dueDate;
}
