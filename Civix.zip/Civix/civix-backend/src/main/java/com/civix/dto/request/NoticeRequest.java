package com.civix.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class NoticeRequest {
    @NotBlank(message = "Title is required")
    @Size(min = 5, max = 255)
    private String title;

    @NotBlank(message = "Content is required")
    private String content;

    private String noticeType = "GENERAL";
    private Boolean isPinned = false;
    private Boolean isPublished = false;
    private String publishDate;
    private String expiryDate;
}
