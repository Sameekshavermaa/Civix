package com.civix.repository;

import com.civix.entity.MaintenanceCharge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MaintenanceChargeRepository extends JpaRepository<MaintenanceCharge, Long> {
    List<MaintenanceCharge> findBySocietyIdOrderByChargeMonthDesc(Long societyId);
    List<MaintenanceCharge> findBySocietyId(Long societyId);
}
