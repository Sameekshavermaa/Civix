package com.civix.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ComplaintUpdateRequest {
    @NotBlank(message = "Status is required")
    private String status;
    private String resolutionComment;
    private String priority;
    private Long assignedTo;
    private String comment;
}
