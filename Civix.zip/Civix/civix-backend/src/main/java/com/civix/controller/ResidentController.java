package com.civix.controller;

import com.civix.dto.request.ResidentRequest;
import com.civix.dto.response.ApiResponse;
import com.civix.dto.response.ResidentResponse;
import com.civix.repository.UserRepository;
import com.civix.service.ResidentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/residents")
@RequiredArgsConstructor
public class ResidentController {

    private final ResidentService residentService;
    private final UserRepository userRepository;

    @GetMapping("/profile")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<ResidentResponse>> getMyProfile(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success(residentService.getResidentByUserId(userId)));
    }

    @PutMapping("/profile")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<ResidentResponse>> updateMyProfile(
            @RequestBody ResidentRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success("Profile updated", residentService.updateProfile(userId, request)));
    }

    @GetMapping("/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<ResidentResponse>>> getAllResidents(@PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(residentService.getAllResidents(societyId)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<ResidentResponse>> getResident(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(residentService.getResidentById(id)));
    }

    @PostMapping("/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<ResidentResponse>> addResident(
            @PathVariable Long societyId,
            @Valid @RequestBody ResidentRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        ResidentResponse response = residentService.addResident(request, userId, societyId);
        return ResponseEntity.ok(ApiResponse.success("Resident added successfully", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<ResidentResponse>> updateResident(
            @PathVariable Long id,
            @Valid @RequestBody ResidentRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success("Resident updated", residentService.updateResident(id, request, userId)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deactivateResident(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        residentService.deactivateResident(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Resident deactivated", null));
    }
}
