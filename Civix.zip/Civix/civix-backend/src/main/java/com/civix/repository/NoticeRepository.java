package com.civix.repository;

import com.civix.entity.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NoticeRepository extends JpaRepository<Notice, Long> {
    List<Notice> findBySocietyIdAndIsPublishedOrderByIsPinnedDescPublishDateDesc(Long societyId, Boolean isPublished);

    @Query("SELECT n FROM Notice n WHERE n.society.id = :societyId AND n.isPublished = true " +
           "AND (n.expiryDate IS NULL OR n.expiryDate > :now) ORDER BY n.isPinned DESC, n.publishDate DESC")
    List<Notice> findActiveNotices(Long societyId, LocalDateTime now);

    @Query("SELECT COUNT(n) FROM Notice n WHERE n.society.id = :societyId AND n.isPublished = true " +
           "AND (n.expiryDate IS NULL OR n.expiryDate > :now)")
    long countActiveNotices(Long societyId, LocalDateTime now);

    List<Notice> findBySocietyIdOrderByCreatedAtDesc(Long societyId);
}
