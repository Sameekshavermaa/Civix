package com.civix.service;

import com.civix.repository.ComplaintRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AiService {

    private final ComplaintRepository complaintRepository;
    private final RestTemplate restTemplate;

    @Value("${civix.ai.service.url}")
    private String aiServiceUrl;

    @Async
    public void analyzeComplaintAsync(Long complaintId, String title, String description) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("complaint_id", complaintId);
            payload.put("title", title);
            payload.put("description", description);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, headers);

            @SuppressWarnings("unchecked")
            ResponseEntity<Map<String, Object>> response = (ResponseEntity<Map<String, Object>>)
                    (ResponseEntity<?>) restTemplate.postForEntity(aiServiceUrl + "/analyze", entity, Map.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> body = response.getBody();
                String aiCategory  = (String) body.get("category");
                String aiPriority  = (String) body.get("priority");
                Object confObj     = body.get("confidence");
                BigDecimal confidence = confObj != null
                        ? new BigDecimal(confObj.toString()) : null;

                complaintRepository.findById(complaintId).ifPresent(complaint -> {
                    complaint.setAiCategory(aiCategory);
                    complaint.setAiPriority(aiPriority);
                    complaint.setAiConfidence(confidence);
                    complaintRepository.save(complaint);
                });
                log.info("AI analysis complete for complaint {}: category={}, priority={}",
                        complaintId, aiCategory, aiPriority);
            }
        } catch (Exception e) {
            log.warn("AI service unavailable for complaint {}: {}", complaintId, e.getMessage());
        }
    }

    public Map<String, Object> analyzeComplaintSync(String title, String description) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("title", title);
            payload.put("description", description);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, headers);

            @SuppressWarnings("unchecked")
            ResponseEntity<Map<String, Object>> response = (ResponseEntity<Map<String, Object>>)
                    (ResponseEntity<?>) restTemplate.postForEntity(aiServiceUrl + "/analyze", entity, Map.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
        } catch (Exception e) {
            log.warn("AI service unavailable: {}", e.getMessage());
        }
        return new HashMap<>();
    }
}
