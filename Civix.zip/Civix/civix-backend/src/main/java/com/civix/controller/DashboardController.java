package com.civix.controller;

import com.civix.dto.response.ApiResponse;
import com.civix.dto.response.DashboardResponse;
import com.civix.repository.ResidentRepository;
import com.civix.repository.UserRepository;
import com.civix.service.DashboardService;
import com.civix.service.ResidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;
    private final UserRepository userRepository;
    private final ResidentRepository residentRepository;
    private final ResidentService residentService;

    @GetMapping("/admin/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<DashboardResponse>> getAdminDashboard(@PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(dashboardService.getAdminDashboard(societyId)));
    }

    @GetMapping("/resident")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<DashboardResponse>> getResidentDashboard(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        Long societyId = residentRepository.findByUserId(userId)
                .orElseThrow().getSociety().getId();
        return ResponseEntity.ok(ApiResponse.success(dashboardService.getAdminDashboard(societyId)));
    }
}
