package com.civix.controller;

import com.civix.dto.request.ComplaintRequest;
import com.civix.dto.request.ComplaintUpdateRequest;
import com.civix.dto.response.ApiResponse;
import com.civix.dto.response.ComplaintResponse;
import com.civix.entity.ComplaintCategory;
import com.civix.repository.ComplaintCategoryRepository;
import com.civix.repository.UserRepository;
import com.civix.service.ComplaintService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;
    private final ComplaintCategoryRepository categoryRepository;
    private final UserRepository userRepository;

    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<List<ComplaintCategory>>> getCategories() {
        return ResponseEntity.ok(ApiResponse.success(categoryRepository.findByIsActiveTrue()));
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> submitComplaint(
            @RequestPart("complaint") @Valid ComplaintRequest request,
            @RequestPart(value = "files", required = false) List<MultipartFile> files,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow().getId();
        ComplaintResponse response = complaintService.submitComplaint(request, userId, files);
        return ResponseEntity.ok(ApiResponse.success("Complaint submitted successfully", response));
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> submitComplaintJson(
            @Valid @RequestBody ComplaintRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow().getId();
        ComplaintResponse response = complaintService.submitComplaint(request, userId, null);
        return ResponseEntity.ok(ApiResponse.success("Complaint submitted successfully", response));
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getMyComplaints(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success(complaintService.getComplaintsByResident(userId)));
    }

    @GetMapping("/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getSocietyComplaints(
            @PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getComplaintsBySociety(societyId)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ComplaintResponse>> getComplaint(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getComplaintById(id)));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody ComplaintUpdateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow().getId();
        ComplaintResponse response = complaintService.updateComplaint(id, request, userId);
        return ResponseEntity.ok(ApiResponse.success("Complaint updated successfully", response));
    }
}
