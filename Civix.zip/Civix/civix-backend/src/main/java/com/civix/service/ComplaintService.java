package com.civix.service;

import com.civix.dto.request.ComplaintRequest;
import com.civix.dto.request.ComplaintUpdateRequest;
import com.civix.dto.response.ComplaintResponse;
import com.civix.entity.*;
import com.civix.exception.BadRequestException;
import com.civix.exception.ResourceNotFoundException;
import com.civix.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final ResidentRepository residentRepository;
    private final UserRepository userRepository;
    private final ComplaintCategoryRepository categoryRepository;
    private final FileStorageService fileStorageService;
    private final AiService aiService;
    private final AuditLogService auditLogService;

    @Transactional
    public ComplaintResponse submitComplaint(ComplaintRequest request, Long userId, List<MultipartFile> files) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));

        Complaint complaint = new Complaint();
        complaint.setComplaintNo(generateComplaintNo(resident.getSociety().getId()));
        complaint.setResident(resident);
        complaint.setSociety(resident.getSociety());
        complaint.setTitle(request.getTitle());
        complaint.setDescription(request.getDescription());
        complaint.setStatus(Complaint.ComplaintStatus.OPEN);

        if (request.getCategoryId() != null) {
            ComplaintCategory category = categoryRepository.findById(request.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", request.getCategoryId()));
            complaint.setCategory(category);
        }

        if (request.getPriority() != null) {
            try {
                complaint.setPriority(Complaint.Priority.valueOf(request.getPriority().toUpperCase()));
            } catch (IllegalArgumentException e) {
                complaint.setPriority(Complaint.Priority.MEDIUM);
            }
        }

        complaintRepository.save(complaint);

        // Add initial status history
        addStatusHistory(complaint, resident.getUser(), null, "OPEN", "Complaint submitted by resident.");

        // Handle file attachments
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    String filePath = fileStorageService.store(file, "complaints");
                    ComplaintAttachment attachment = new ComplaintAttachment();
                    attachment.setComplaint(complaint);
                    attachment.setFileName(file.getOriginalFilename());
                    attachment.setFilePath(filePath);
                    attachment.setFileType(file.getContentType());
                    attachment.setFileSize(file.getSize());
                    complaint.getAttachments().add(attachment);
                }
            }
            complaintRepository.save(complaint);
        }

        // Async AI categorization
        aiService.analyzeComplaintAsync(complaint.getId(), request.getTitle(), request.getDescription());

        auditLogService.log(resident.getUser(), "COMPLAINT_SUBMIT", "Complaint", complaint.getId(),
                null, complaint.getComplaintNo());

        return toResponse(complaint);
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getComplaintsByResident(Long userId) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));
        return complaintRepository.findByResidentId(resident.getId())
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getComplaintsBySociety(Long societyId) {
        return complaintRepository.findBySocietyId(societyId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ComplaintResponse getComplaintById(Long id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint", id));
        return toResponse(complaint);
    }

    @Transactional
    public ComplaintResponse updateComplaint(Long id, ComplaintUpdateRequest request, Long adminUserId) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint", id));

        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        String oldStatus = complaint.getStatus().name();

        try {
            Complaint.ComplaintStatus newStatus = Complaint.ComplaintStatus.valueOf(request.getStatus().toUpperCase());
            complaint.setStatus(newStatus);
            if (newStatus == Complaint.ComplaintStatus.RESOLVED || newStatus == Complaint.ComplaintStatus.CLOSED) {
                complaint.setResolvedAt(LocalDateTime.now());
            }
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Invalid status: " + request.getStatus());
        }

        if (request.getPriority() != null) {
            try {
                complaint.setPriority(Complaint.Priority.valueOf(request.getPriority().toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new BadRequestException("Invalid priority: " + request.getPriority());
            }
        }

        if (request.getResolutionComment() != null) {
            complaint.setResolutionComment(request.getResolutionComment());
        }

        if (request.getAssignedTo() != null) {
            User assignee = userRepository.findById(request.getAssignedTo())
                    .orElseThrow(() -> new ResourceNotFoundException("User", request.getAssignedTo()));
            complaint.setAssignedTo(assignee);
        }

        addStatusHistory(complaint, admin, oldStatus, request.getStatus(),
                request.getComment() != null ? request.getComment() : request.getResolutionComment());

        complaintRepository.save(complaint);
        auditLogService.log(admin, "COMPLAINT_UPDATE", "Complaint", complaint.getId(), oldStatus, request.getStatus());

        return toResponse(complaint);
    }

    @Transactional
    public void updateAiAnalysis(Long complaintId, String aiCategory, String aiPriority,
                                  java.math.BigDecimal aiConfidence) {
        complaintRepository.findById(complaintId).ifPresent(complaint -> {
            complaint.setAiCategory(aiCategory);
            complaint.setAiPriority(aiPriority);
            complaint.setAiConfidence(aiConfidence);
            complaintRepository.save(complaint);
        });
    }

    private void addStatusHistory(Complaint complaint, User changedBy, String oldStatus,
                                   String newStatus, String comment) {
        ComplaintStatusHistory history = new ComplaintStatusHistory();
        history.setComplaint(complaint);
        history.setChangedBy(changedBy);
        history.setOldStatus(oldStatus);
        history.setNewStatus(newStatus);
        history.setComment(comment);
        complaint.getStatusHistory().add(history);
    }

    private String generateComplaintNo(Long societyId) {
        String year = String.valueOf(LocalDateTime.now().getYear());
        long count = complaintRepository.countBySociety(societyId) + 1;
        return String.format("CMP-%s-%04d", year, count);
    }

    public ComplaintResponse toResponse(Complaint c) {
        ComplaintResponse r = new ComplaintResponse();
        r.setId(c.getId());
        r.setComplaintNo(c.getComplaintNo());
        r.setResidentId(c.getResident().getId());
        r.setResidentName(c.getResident().getUser().getFullName());
        r.setResidentUnit(c.getResident().getUnitNumber());
        r.setSocietyId(c.getSociety().getId());
        if (c.getCategory() != null) {
            r.setCategoryId(c.getCategory().getId());
            r.setCategoryName(c.getCategory().getName());
        }
        r.setTitle(c.getTitle());
        r.setDescription(c.getDescription());
        r.setStatus(c.getStatus().name());
        r.setPriority(c.getPriority().name());
        if (c.getAssignedTo() != null) {
            r.setAssignedToId(c.getAssignedTo().getId());
            r.setAssignedToName(c.getAssignedTo().getFullName());
        }
        r.setResolutionComment(c.getResolutionComment());
        r.setResolvedAt(c.getResolvedAt());
        r.setAiCategory(c.getAiCategory());
        r.setAiPriority(c.getAiPriority());
        r.setAiConfidence(c.getAiConfidence());
        r.setCreatedAt(c.getCreatedAt());
        r.setUpdatedAt(c.getUpdatedAt());

        r.setAttachments(c.getAttachments().stream().map(a -> {
            ComplaintResponse.AttachmentResponse ar = new ComplaintResponse.AttachmentResponse();
            ar.setId(a.getId());
            ar.setFileName(a.getFileName());
            ar.setFilePath(a.getFilePath());
            ar.setFileType(a.getFileType());
            ar.setFileSize(a.getFileSize());
            ar.setUploadedAt(a.getUploadedAt());
            return ar;
        }).collect(Collectors.toList()));

        r.setStatusHistory(c.getStatusHistory().stream().map(h -> {
            ComplaintResponse.StatusHistoryResponse hr = new ComplaintResponse.StatusHistoryResponse();
            hr.setId(h.getId());
            hr.setChangedByName(h.getChangedBy().getFullName());
            hr.setOldStatus(h.getOldStatus());
            hr.setNewStatus(h.getNewStatus());
            hr.setComment(h.getComment());
            hr.setChangedAt(h.getChangedAt());
            return hr;
        }).collect(Collectors.toList()));

        return r;
    }
}
