package com.civix.dto.response;

import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;

@Data
@Builder
public class DashboardResponse {
    private long totalResidents;
    private long openComplaints;
    private long inProgressComplaints;
    private long resolvedComplaints;
    private long totalComplaints;
    private long activeNotices;
    private long pendingMaintenance;
    private BigDecimal monthlyCollections;
    private BigDecimal pendingAmount;
    private long totalUnits;
}
