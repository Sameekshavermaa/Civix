package com.civix.service;

import com.civix.dto.request.MaintenanceChargeRequest;
import com.civix.dto.request.PaymentRequest;
import com.civix.dto.response.MaintenanceResponse;
import com.civix.dto.response.PaymentResponse;
import com.civix.entity.*;
import com.civix.exception.BadRequestException;
import com.civix.exception.ResourceNotFoundException;
import com.civix.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MaintenanceService {

    private final MaintenanceChargeRepository chargeRepository;
    private final MaintenanceRecordRepository recordRepository;
    private final PaymentRepository paymentRepository;
    private final ResidentRepository residentRepository;
    private final SocietyRepository societyRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    @Transactional
    public void createMonthlyCharges(MaintenanceChargeRequest request, Long adminUserId, Long societyId) {
        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society", societyId));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        LocalDate chargeMonth = YearMonth.parse(request.getChargeMonth()).atDay(1);
        LocalDate dueDate = LocalDate.parse(request.getDueDate());

        MaintenanceCharge charge = new MaintenanceCharge();
        charge.setSociety(society);
        charge.setChargeMonth(chargeMonth);
        charge.setBaseAmount(request.getBaseAmount());
        charge.setLateFee(request.getLateFee() != null ? request.getLateFee() : BigDecimal.ZERO);
        charge.setDescription(request.getDescription());
        charge.setDueDate(dueDate);
        charge.setCreatedBy(admin);
        chargeRepository.save(charge);

        List<Resident> activeResidents = residentRepository.findBySocietyIdAndIsActive(societyId, true);
        for (Resident resident : activeResidents) {
            MaintenanceRecord record = new MaintenanceRecord();
            record.setMaintenanceCharge(charge);
            record.setResident(resident);
            record.setAmountDue(request.getBaseAmount());
            record.setAmountPaid(BigDecimal.ZERO);
            record.setPaymentStatus(MaintenanceRecord.PaymentStatus.PENDING);
            record.setDueDate(dueDate);
            recordRepository.save(record);
        }

        auditLogService.log(admin, "MAINTENANCE_CHARGE_CREATE", "MaintenanceCharge",
                charge.getId(), null, chargeMonth.toString());
    }

    @Transactional(readOnly = true)
    public List<MaintenanceResponse> getResidentMaintenance(Long userId) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));
        return recordRepository.findByResidentId(resident.getId())
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MaintenanceResponse> getSocietyMaintenance(Long societyId) {
        List<MaintenanceCharge> charges = chargeRepository.findBySocietyId(societyId);
        return charges.stream()
                .flatMap(c -> recordRepository.findByMaintenanceChargeId(c.getId()).stream())
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public PaymentResponse recordPayment(PaymentRequest request, Long adminUserId) {
        MaintenanceRecord record = recordRepository.findById(request.getMaintenanceRecordId())
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceRecord", request.getMaintenanceRecordId()));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        Payment payment = new Payment();
        payment.setPaymentRef("PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        payment.setMaintenanceRecord(record);
        payment.setResident(record.getResident());
        payment.setAmount(request.getAmount());
        payment.setPaymentDate(LocalDate.parse(request.getPaymentDate()));
        payment.setRemarks(request.getRemarks());
        payment.setRecordedBy(admin);
        payment.setTransactionId(request.getTransactionId());

        try {
            payment.setPaymentMode(Payment.PaymentMode.valueOf(request.getPaymentMode().toUpperCase()));
        } catch (Exception e) {
            payment.setPaymentMode(Payment.PaymentMode.CASH);
        }

        paymentRepository.save(payment);

        BigDecimal newPaid = record.getAmountPaid().add(request.getAmount());
        record.setAmountPaid(newPaid);
        if (newPaid.compareTo(record.getAmountDue()) >= 0) {
            record.setPaymentStatus(MaintenanceRecord.PaymentStatus.PAID);
            record.setPaidDate(payment.getPaymentDate());
        } else {
            record.setPaymentStatus(MaintenanceRecord.PaymentStatus.PARTIAL);
        }
        recordRepository.save(record);

        auditLogService.log(admin, "PAYMENT_RECORD", "Payment", payment.getId(),
                null, payment.getPaymentRef());
        return toPaymentResponse(payment);
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> getResidentPayments(Long userId) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));
        return paymentRepository.findByResidentId(resident.getId())
                .stream().map(this::toPaymentResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> getSocietyPayments(Long societyId) {
        return paymentRepository.findBySocietyId(societyId)
                .stream().map(this::toPaymentResponse).collect(Collectors.toList());
    }

    public MaintenanceResponse toResponse(MaintenanceRecord mr) {
        MaintenanceResponse r = new MaintenanceResponse();
        r.setId(mr.getId());
        r.setMaintenanceChargeId(mr.getMaintenanceCharge().getId());
        r.setChargeMonth(mr.getMaintenanceCharge().getChargeMonth().toString());
        r.setResidentId(mr.getResident().getId());
        r.setResidentName(mr.getResident().getUser().getFullName());
        r.setUnitNumber(mr.getResident().getUnitNumber());
        r.setAmountDue(mr.getAmountDue());
        r.setAmountPaid(mr.getAmountPaid());
        r.setBalance(mr.getAmountDue().subtract(mr.getAmountPaid()));
        r.setPaymentStatus(mr.getPaymentStatus().name());
        r.setDueDate(mr.getDueDate());
        r.setPaidDate(mr.getPaidDate());
        r.setLateFeeApplied(mr.getLateFeeApplied());
        r.setNotes(mr.getNotes());
        r.setCreatedAt(mr.getCreatedAt());
        r.setUpdatedAt(mr.getUpdatedAt());
        return r;
    }

    public PaymentResponse toPaymentResponse(Payment p) {
        PaymentResponse r = new PaymentResponse();
        r.setId(p.getId());
        r.setPaymentRef(p.getPaymentRef());
        r.setMaintenanceRecordId(p.getMaintenanceRecord().getId());
        r.setResidentId(p.getResident().getId());
        r.setResidentName(p.getResident().getUser().getFullName());
        r.setUnitNumber(p.getResident().getUnitNumber());
        r.setAmount(p.getAmount());
        r.setPaymentMode(p.getPaymentMode().name());
        r.setTransactionId(p.getTransactionId());
        r.setPaymentDate(p.getPaymentDate());
        r.setRemarks(p.getRemarks());
        r.setRecordedByName(p.getRecordedBy().getFullName());
        r.setCreatedAt(p.getCreatedAt());
        return r;
    }
}
