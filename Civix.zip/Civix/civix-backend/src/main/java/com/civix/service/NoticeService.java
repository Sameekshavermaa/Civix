package com.civix.service;

import com.civix.dto.request.NoticeRequest;
import com.civix.dto.response.NoticeResponse;
import com.civix.entity.Notice;
import com.civix.entity.Society;
import com.civix.entity.User;
import com.civix.exception.ResourceNotFoundException;
import com.civix.repository.NoticeRepository;
import com.civix.repository.SocietyRepository;
import com.civix.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository noticeRepository;
    private final SocietyRepository societyRepository;
    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    @Transactional
    public NoticeResponse createNotice(NoticeRequest request, Long adminUserId, Long societyId) {
        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society", societyId));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        Notice notice = new Notice();
        notice.setSociety(society);
        notice.setCreatedBy(admin);
        notice.setTitle(request.getTitle());
        notice.setContent(request.getContent());
        notice.setIsPinned(request.getIsPinned() != null ? request.getIsPinned() : false);
        notice.setIsPublished(request.getIsPublished() != null ? request.getIsPublished() : false);

        try {
            notice.setNoticeType(Notice.NoticeType.valueOf(request.getNoticeType().toUpperCase()));
        } catch (Exception e) {
            notice.setNoticeType(Notice.NoticeType.GENERAL);
        }

        if (request.getPublishDate() != null && !request.getPublishDate().isBlank()) {
            notice.setPublishDate(LocalDateTime.parse(request.getPublishDate(), DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }
        if (request.getExpiryDate() != null && !request.getExpiryDate().isBlank()) {
            notice.setExpiryDate(LocalDateTime.parse(request.getExpiryDate(), DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }

        noticeRepository.save(notice);
        auditLogService.log(admin, "NOTICE_CREATE", "Notice", notice.getId(), null, notice.getTitle());
        return toResponse(notice);
    }

    @Transactional
    public NoticeResponse updateNotice(Long id, NoticeRequest request, Long adminUserId) {
        Notice notice = noticeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notice", id));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        String oldTitle = notice.getTitle();
        notice.setTitle(request.getTitle());
        notice.setContent(request.getContent());
        if (request.getIsPinned() != null) notice.setIsPinned(request.getIsPinned());
        if (request.getIsPublished() != null) notice.setIsPublished(request.getIsPublished());

        try {
            notice.setNoticeType(Notice.NoticeType.valueOf(request.getNoticeType().toUpperCase()));
        } catch (Exception ignored) {}

        if (request.getPublishDate() != null && !request.getPublishDate().isBlank()) {
            notice.setPublishDate(LocalDateTime.parse(request.getPublishDate(), DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }
        if (request.getExpiryDate() != null && !request.getExpiryDate().isBlank()) {
            notice.setExpiryDate(LocalDateTime.parse(request.getExpiryDate(), DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }

        noticeRepository.save(notice);
        auditLogService.log(admin, "NOTICE_UPDATE", "Notice", notice.getId(), oldTitle, notice.getTitle());
        return toResponse(notice);
    }

    @Transactional
    public void deleteNotice(Long id, Long adminUserId) {
        Notice notice = noticeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notice", id));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));
        auditLogService.log(admin, "NOTICE_DELETE", "Notice", id, notice.getTitle(), null);
        noticeRepository.delete(notice);
    }

    @Transactional(readOnly = true)
    public List<NoticeResponse> getActiveNotices(Long societyId) {
        return noticeRepository.findActiveNotices(societyId, LocalDateTime.now())
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NoticeResponse> getAllNotices(Long societyId) {
        return noticeRepository.findBySocietyIdOrderByCreatedAtDesc(societyId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public NoticeResponse getNoticeById(Long id) {
        Notice notice = noticeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notice", id));
        notice.setViewCount(notice.getViewCount() + 1);
        noticeRepository.save(notice);
        return toResponse(notice);
    }

    @Transactional
    public NoticeResponse togglePublish(Long id, Long adminUserId) {
        Notice notice = noticeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notice", id));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));
        notice.setIsPublished(!notice.getIsPublished());
        if (notice.getIsPublished()) notice.setPublishDate(LocalDateTime.now());
        noticeRepository.save(notice);
        auditLogService.log(admin, notice.getIsPublished() ? "NOTICE_PUBLISH" : "NOTICE_UNPUBLISH",
                "Notice", id, null, null);
        return toResponse(notice);
    }

    public NoticeResponse toResponse(Notice n) {
        NoticeResponse r = new NoticeResponse();
        r.setId(n.getId());
        r.setSocietyId(n.getSociety().getId());
        r.setCreatedById(n.getCreatedBy().getId());
        r.setCreatedByName(n.getCreatedBy().getFullName());
        r.setTitle(n.getTitle());
        r.setContent(n.getContent());
        r.setNoticeType(n.getNoticeType().name());
        r.setIsPinned(n.getIsPinned());
        r.setPublishDate(n.getPublishDate());
        r.setExpiryDate(n.getExpiryDate());
        r.setIsPublished(n.getIsPublished());
        r.setAttachmentUrl(n.getAttachmentUrl());
        r.setViewCount(n.getViewCount());
        r.setCreatedAt(n.getCreatedAt());
        r.setUpdatedAt(n.getUpdatedAt());
        return r;
    }
}
