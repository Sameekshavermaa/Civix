package com.civix.service;

import com.civix.dto.response.DashboardResponse;
import com.civix.entity.Complaint;
import com.civix.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final ResidentRepository residentRepository;
    private final ComplaintRepository complaintRepository;
    private final NoticeRepository noticeRepository;
    private final MaintenanceRecordRepository maintenanceRecordRepository;
    private final SocietyRepository societyRepository;

    @Transactional(readOnly = true)
    public DashboardResponse getAdminDashboard(Long societyId) {
        long totalResidents   = residentRepository.countActiveBySociety(societyId);
        long openComplaints   = complaintRepository.countBySocietyAndStatus(societyId, Complaint.ComplaintStatus.OPEN);
        long inProgress       = complaintRepository.countBySocietyAndStatus(societyId, Complaint.ComplaintStatus.IN_PROGRESS);
        long resolved         = complaintRepository.countBySocietyAndStatus(societyId, Complaint.ComplaintStatus.RESOLVED);
        long totalComplaints  = complaintRepository.countBySociety(societyId);
        long activeNotices    = noticeRepository.countActiveNotices(societyId, LocalDateTime.now());
        long pendingMaint     = maintenanceRecordRepository.countPendingBySociety(societyId);
        BigDecimal monthly    = maintenanceRecordRepository.sumMonthlyCollections(societyId);
        BigDecimal pending    = maintenanceRecordRepository.sumPendingAmount(societyId);
        long totalUnits       = societyRepository.findById(societyId)
                                    .map(s -> (long) s.getTotalUnits()).orElse(0L);

        return DashboardResponse.builder()
                .totalResidents(totalResidents)
                .openComplaints(openComplaints)
                .inProgressComplaints(inProgress)
                .resolvedComplaints(resolved)
                .totalComplaints(totalComplaints)
                .activeNotices(activeNotices)
                .pendingMaintenance(pendingMaint)
                .monthlyCollections(monthly != null ? monthly : BigDecimal.ZERO)
                .pendingAmount(pending != null ? pending : BigDecimal.ZERO)
                .totalUnits(totalUnits)
                .build();
    }
}
