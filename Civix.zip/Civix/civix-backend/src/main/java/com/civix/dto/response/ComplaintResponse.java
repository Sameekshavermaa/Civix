package com.civix.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ComplaintResponse {
    private Long id;
    private String complaintNo;
    private Long residentId;
    private String residentName;
    private String residentUnit;
    private Long societyId;
    private Long categoryId;
    private String categoryName;
    private String title;
    private String description;
    private String status;
    private String priority;
    private Long assignedToId;
    private String assignedToName;
    private String resolutionComment;
    private LocalDateTime resolvedAt;
    private String aiCategory;
    private String aiPriority;
    private BigDecimal aiConfidence;
    private List<AttachmentResponse> attachments;
    private List<StatusHistoryResponse> statusHistory;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Data
    public static class AttachmentResponse {
        private Long id;
        private String fileName;
        private String filePath;
        private String fileType;
        private Long fileSize;
        private LocalDateTime uploadedAt;
    }

    @Data
    public static class StatusHistoryResponse {
        private Long id;
        private String changedByName;
        private String oldStatus;
        private String newStatus;
        private String comment;
        private LocalDateTime changedAt;
    }
}
