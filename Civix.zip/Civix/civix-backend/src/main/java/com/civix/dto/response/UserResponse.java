package com.civix.dto.response;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class UserResponse {
    private Long id;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private String profileImage;
    private Boolean isActive;
    private Boolean emailVerified;
    private LocalDateTime lastLogin;
    private List<String> roles;
    private LocalDateTime createdAt;
}
