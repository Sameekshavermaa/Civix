package com.civix.repository;

import com.civix.entity.Resident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResidentRepository extends JpaRepository<Resident, Long> {
    Optional<Resident> findByUserId(Long userId);
    List<Resident> findBySocietyId(Long societyId);
    List<Resident> findBySocietyIdAndIsActive(Long societyId, Boolean isActive);
    boolean existsByUserIdAndSocietyId(Long userId, Long societyId);

    @Query("SELECT COUNT(r) FROM Resident r WHERE r.society.id = :societyId AND r.isActive = true")
    long countActiveBySociety(Long societyId);
}
