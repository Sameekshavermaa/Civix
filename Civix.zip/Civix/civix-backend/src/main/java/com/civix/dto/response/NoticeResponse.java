package com.civix.dto.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class NoticeResponse {
    private Long id;
    private Long societyId;
    private Long createdById;
    private String createdByName;
    private String title;
    private String content;
    private String noticeType;
    private Boolean isPinned;
    private LocalDateTime publishDate;
    private LocalDateTime expiryDate;
    private Boolean isPublished;
    private String attachmentUrl;
    private Integer viewCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
