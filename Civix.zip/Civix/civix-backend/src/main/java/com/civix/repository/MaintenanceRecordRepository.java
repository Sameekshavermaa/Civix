package com.civix.repository;

import com.civix.entity.MaintenanceRecord;
import com.civix.entity.MaintenanceRecord.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface MaintenanceRecordRepository extends JpaRepository<MaintenanceRecord, Long> {
    List<MaintenanceRecord> findByResidentId(Long residentId);
    List<MaintenanceRecord> findByMaintenanceChargeId(Long chargeId);
    List<MaintenanceRecord> findByResidentIdAndPaymentStatus(Long residentId, PaymentStatus status);

    @Query("SELECT COUNT(mr) FROM MaintenanceRecord mr WHERE mr.resident.society.id = :societyId AND mr.paymentStatus IN (com.civix.entity.MaintenanceRecord.PaymentStatus.PENDING, com.civix.entity.MaintenanceRecord.PaymentStatus.OVERDUE, com.civix.entity.MaintenanceRecord.PaymentStatus.PARTIAL)")
    long countPendingBySociety(@org.springframework.data.repository.query.Param("societyId") Long societyId);

    @Query("SELECT COALESCE(SUM(mr.amountPaid), 0) FROM MaintenanceRecord mr WHERE mr.resident.society.id = :societyId AND MONTH(mr.paidDate) = MONTH(CURRENT_DATE) AND YEAR(mr.paidDate) = YEAR(CURRENT_DATE)")
    BigDecimal sumMonthlyCollections(@org.springframework.data.repository.query.Param("societyId") Long societyId);

    @Query("SELECT COALESCE(SUM(mr.amountDue - mr.amountPaid), 0) FROM MaintenanceRecord mr WHERE mr.resident.society.id = :societyId AND mr.paymentStatus IN (com.civix.entity.MaintenanceRecord.PaymentStatus.PENDING, com.civix.entity.MaintenanceRecord.PaymentStatus.OVERDUE, com.civix.entity.MaintenanceRecord.PaymentStatus.PARTIAL)")
    BigDecimal sumPendingAmount(@org.springframework.data.repository.query.Param("societyId") Long societyId);
}
