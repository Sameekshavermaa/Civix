package com.civix.repository;

import com.civix.entity.Complaint;
import com.civix.entity.Complaint.ComplaintStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    Optional<Complaint> findByComplaintNo(String complaintNo);
    List<Complaint> findByResidentId(Long residentId);
    List<Complaint> findBySocietyId(Long societyId);
    List<Complaint> findBySocietyIdAndStatus(Long societyId, ComplaintStatus status);
    List<Complaint> findByResidentIdAndStatus(Long residentId, ComplaintStatus status);

    @Query("SELECT COUNT(c) FROM Complaint c WHERE c.society.id = :societyId AND c.status = :status")
    long countBySocietyAndStatus(Long societyId, ComplaintStatus status);

    @Query("SELECT COUNT(c) FROM Complaint c WHERE c.society.id = :societyId")
    long countBySociety(Long societyId);

    @Query("SELECT MAX(c.id) FROM Complaint c WHERE c.society.id = :societyId")
    Long findMaxIdBySociety(Long societyId);
}
