package com.civix.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ResidentRequest {
    @NotBlank(message = "Full name is required")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email
    private String email;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[0-9]{10}$")
    private String phone;

    @NotBlank(message = "Unit number is required")
    private String unitNumber;

    private String blockName;
    private Integer floorNumber;
    private String occupancyType = "OWNER";
    private String moveInDate;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private String username;
    private String password;
}
