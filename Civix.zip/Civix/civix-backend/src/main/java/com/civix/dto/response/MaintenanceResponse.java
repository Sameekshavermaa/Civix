package com.civix.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class MaintenanceResponse {
    private Long id;
    private Long maintenanceChargeId;
    private String chargeMonth;
    private Long residentId;
    private String residentName;
    private String unitNumber;
    private BigDecimal amountDue;
    private BigDecimal amountPaid;
    private BigDecimal balance;
    private String paymentStatus;
    private LocalDate dueDate;
    private LocalDate paidDate;
    private BigDecimal lateFeeApplied;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
