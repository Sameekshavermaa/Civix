package com.civix.repository;

import com.civix.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByResidentId(Long residentId);
    List<Payment> findByMaintenanceRecordId(Long recordId);
    boolean existsByPaymentRef(String paymentRef);

    @Query("SELECT p FROM Payment p WHERE p.resident.society.id = :societyId ORDER BY p.paymentDate DESC")
    List<Payment> findBySocietyId(Long societyId);
}
