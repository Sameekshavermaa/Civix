package com.civix.dto.response;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentResponse {
    private Long id;
    private String paymentRef;
    private Long maintenanceRecordId;
    private Long residentId;
    private String residentName;
    private String unitNumber;
    private BigDecimal amount;
    private String paymentMode;
    private String transactionId;
    private LocalDate paymentDate;
    private String remarks;
    private String recordedByName;
    private LocalDateTime createdAt;
}
