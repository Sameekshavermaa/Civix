package com.civix.dto.response;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ResidentResponse {
    private Long id;
    private Long userId;
    private String fullName;
    private String email;
    private String phone;
    private String profileImage;
    private Long societyId;
    private String societyName;
    private String unitNumber;
    private String blockName;
    private Integer floorNumber;
    private String occupancyType;
    private LocalDate moveInDate;
    private LocalDate moveOutDate;
    private Boolean isActive;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private LocalDateTime createdAt;
}
