package com.civix.controller;

import com.civix.dto.request.NoticeRequest;
import com.civix.dto.response.ApiResponse;
import com.civix.dto.response.NoticeResponse;
import com.civix.repository.UserRepository;
import com.civix.service.NoticeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notices")
@RequiredArgsConstructor
public class NoticeController {

    private final NoticeService noticeService;
    private final UserRepository userRepository;

    @GetMapping("/society/{societyId}")
    public ResponseEntity<ApiResponse<List<NoticeResponse>>> getActiveNotices(@PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(noticeService.getActiveNotices(societyId)));
    }

    @GetMapping("/society/{societyId}/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<NoticeResponse>>> getAllNotices(@PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(noticeService.getAllNotices(societyId)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<NoticeResponse>> getNotice(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(noticeService.getNoticeById(id)));
    }

    @PostMapping("/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<NoticeResponse>> createNotice(
            @PathVariable Long societyId,
            @Valid @RequestBody NoticeRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        NoticeResponse response = noticeService.createNotice(request, userId, societyId);
        return ResponseEntity.ok(ApiResponse.success("Notice created successfully", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<NoticeResponse>> updateNotice(
            @PathVariable Long id,
            @Valid @RequestBody NoticeRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success("Notice updated successfully", noticeService.updateNotice(id, request, userId)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteNotice(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        noticeService.deleteNotice(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Notice deleted successfully", null));
    }

    @PatchMapping("/{id}/publish")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<NoticeResponse>> togglePublish(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success(noticeService.togglePublish(id, userId)));
    }
}
