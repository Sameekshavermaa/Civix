package com.civix.service;

import com.civix.dto.request.ResidentRequest;
import com.civix.dto.response.ResidentResponse;
import com.civix.entity.*;
import com.civix.exception.BadRequestException;
import com.civix.exception.DuplicateResourceException;
import com.civix.exception.ResourceNotFoundException;
import com.civix.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ResidentService {

    private final ResidentRepository residentRepository;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final SocietyRepository societyRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    @Transactional
    public ResidentResponse addResident(ResidentRequest request, Long adminUserId, Long societyId) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email '" + request.getEmail() + "' is already registered.");
        }
        String username = request.getUsername() != null && !request.getUsername().isBlank()
                ? request.getUsername()
                : request.getEmail().split("@")[0].toLowerCase().replaceAll("[^a-z0-9._-]", "");
        if (userRepository.existsByUsername(username)) {
            username = username + UUID.randomUUID().toString().substring(0, 4);
        }

        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society", societyId));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        String rawPassword = request.getPassword() != null && !request.getPassword().isBlank()
                ? request.getPassword() : "Resident@123";

        User user = new User();
        user.setFullName(request.getFullName());
        user.setUsername(username);
        user.setEmail(request.getEmail());
        user.setPasswordHash(passwordEncoder.encode(rawPassword));
        user.setPhone(request.getPhone());
        user.setIsActive(true);
        user.setEmailVerified(false);

        Role residentRole = roleRepository.findByName("ROLE_RESIDENT")
                .orElseThrow(() -> new ResourceNotFoundException("Role ROLE_RESIDENT not found"));
        user.setRoles(new HashSet<>(Set.of(residentRole)));
        userRepository.save(user);

        Resident resident = new Resident();
        resident.setUser(user);
        resident.setSociety(society);
        resident.setUnitNumber(request.getUnitNumber());
        resident.setBlockName(request.getBlockName());
        resident.setFloorNumber(request.getFloorNumber());
        resident.setEmergencyContactName(request.getEmergencyContactName());
        resident.setEmergencyContactPhone(request.getEmergencyContactPhone());
        if (request.getOccupancyType() != null) {
            try {
                resident.setOccupancyType(Resident.OccupancyType.valueOf(request.getOccupancyType().toUpperCase()));
            } catch (IllegalArgumentException e) {
                resident.setOccupancyType(Resident.OccupancyType.OWNER);
            }
        }
        if (request.getMoveInDate() != null && !request.getMoveInDate().isBlank()) {
            resident.setMoveInDate(LocalDate.parse(request.getMoveInDate()));
        }
        residentRepository.save(resident);

        auditLogService.log(admin, "RESIDENT_ADD", "Resident", resident.getId(), null, user.getEmail());
        return toResponse(resident);
    }

    @Transactional
    public ResidentResponse updateResident(Long residentId, ResidentRequest request, Long adminUserId) {
        Resident resident = residentRepository.findById(residentId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident", residentId));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));

        User user = resident.getUser();
        user.setFullName(request.getFullName());
        user.setPhone(request.getPhone());
        userRepository.save(user);

        resident.setUnitNumber(request.getUnitNumber());
        resident.setBlockName(request.getBlockName());
        resident.setFloorNumber(request.getFloorNumber());
        resident.setEmergencyContactName(request.getEmergencyContactName());
        resident.setEmergencyContactPhone(request.getEmergencyContactPhone());
        if (request.getOccupancyType() != null) {
            try {
                resident.setOccupancyType(Resident.OccupancyType.valueOf(request.getOccupancyType().toUpperCase()));
            } catch (IllegalArgumentException ignored) {}
        }
        residentRepository.save(resident);

        auditLogService.log(admin, "RESIDENT_UPDATE", "Resident", residentId, null, user.getEmail());
        return toResponse(resident);
    }

    @Transactional(readOnly = true)
    public List<ResidentResponse> getAllResidents(Long societyId) {
        return residentRepository.findBySocietyId(societyId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ResidentResponse getResidentByUserId(Long userId) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));
        return toResponse(resident);
    }

    @Transactional(readOnly = true)
    public ResidentResponse getResidentById(Long residentId) {
        Resident resident = residentRepository.findById(residentId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident", residentId));
        return toResponse(resident);
    }

    @Transactional
    public ResidentResponse updateProfile(Long userId, ResidentRequest request) {
        Resident resident = residentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for user: " + userId));
        User user = resident.getUser();
        if (request.getFullName() != null) user.setFullName(request.getFullName());
        if (request.getPhone() != null) user.setPhone(request.getPhone());
        userRepository.save(user);

        if (request.getEmergencyContactName() != null) resident.setEmergencyContactName(request.getEmergencyContactName());
        if (request.getEmergencyContactPhone() != null) resident.setEmergencyContactPhone(request.getEmergencyContactPhone());
        residentRepository.save(resident);

        return toResponse(resident);
    }

    @Transactional
    public void deactivateResident(Long residentId, Long adminUserId) {
        Resident resident = residentRepository.findById(residentId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident", residentId));
        User admin = userRepository.findById(adminUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User", adminUserId));
        resident.setIsActive(false);
        resident.getUser().setIsActive(false);
        residentRepository.save(resident);
        auditLogService.log(admin, "RESIDENT_DEACTIVATE", "Resident", residentId, "active", "inactive");
    }

    public ResidentResponse toResponse(Resident r) {
        ResidentResponse res = new ResidentResponse();
        res.setId(r.getId());
        res.setUserId(r.getUser().getId());
        res.setFullName(r.getUser().getFullName());
        res.setEmail(r.getUser().getEmail());
        res.setPhone(r.getUser().getPhone());
        res.setProfileImage(r.getUser().getProfileImage());
        res.setSocietyId(r.getSociety().getId());
        res.setSocietyName(r.getSociety().getName());
        res.setUnitNumber(r.getUnitNumber());
        res.setBlockName(r.getBlockName());
        res.setFloorNumber(r.getFloorNumber());
        res.setOccupancyType(r.getOccupancyType().name());
        res.setMoveInDate(r.getMoveInDate());
        res.setMoveOutDate(r.getMoveOutDate());
        res.setIsActive(r.getIsActive());
        res.setEmergencyContactName(r.getEmergencyContactName());
        res.setEmergencyContactPhone(r.getEmergencyContactPhone());
        res.setCreatedAt(r.getCreatedAt());
        return res;
    }
}
