package com.civix.controller;

import com.civix.dto.request.MaintenanceChargeRequest;
import com.civix.dto.request.PaymentRequest;
import com.civix.dto.response.ApiResponse;
import com.civix.dto.response.MaintenanceResponse;
import com.civix.dto.response.PaymentResponse;
import com.civix.repository.UserRepository;
import com.civix.service.MaintenanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/maintenance")
@RequiredArgsConstructor
public class MaintenanceController {

    private final MaintenanceService maintenanceService;
    private final UserRepository userRepository;

    @GetMapping("/my")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<List<MaintenanceResponse>>> getMyMaintenance(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success(maintenanceService.getResidentMaintenance(userId)));
    }

    @GetMapping("/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<MaintenanceResponse>>> getSocietyMaintenance(
            @PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(maintenanceService.getSocietyMaintenance(societyId)));
    }

    @PostMapping("/society/{societyId}/charges")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> createMonthlyCharges(
            @PathVariable Long societyId,
            @Valid @RequestBody MaintenanceChargeRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        maintenanceService.createMonthlyCharges(request, userId, societyId);
        return ResponseEntity.ok(ApiResponse.success("Monthly charges created for all residents", null));
    }

    @PostMapping("/payments")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<PaymentResponse>> recordPayment(
            @Valid @RequestBody PaymentRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        PaymentResponse response = maintenanceService.recordPayment(request, userId);
        return ResponseEntity.ok(ApiResponse.success("Payment recorded successfully", response));
    }

    @GetMapping("/payments/my")
    @PreAuthorize("hasRole('RESIDENT')")
    public ResponseEntity<ApiResponse<List<PaymentResponse>>> getMyPayments(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = userRepository.findByUsername(userDetails.getUsername()).orElseThrow().getId();
        return ResponseEntity.ok(ApiResponse.success(maintenanceService.getResidentPayments(userId)));
    }

    @GetMapping("/payments/society/{societyId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<PaymentResponse>>> getSocietyPayments(
            @PathVariable Long societyId) {
        return ResponseEntity.ok(ApiResponse.success(maintenanceService.getSocietyPayments(societyId)));
    }
}
