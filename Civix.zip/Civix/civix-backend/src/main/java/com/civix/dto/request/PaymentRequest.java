package com.civix.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentRequest {
    @NotNull(message = "Maintenance record ID is required")
    private Long maintenanceRecordId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be positive")
    private BigDecimal amount;

    private String paymentMode = "CASH";
    private String transactionId;

    @NotBlank(message = "Payment date is required")
    private String paymentDate;

    private String remarks;
}
