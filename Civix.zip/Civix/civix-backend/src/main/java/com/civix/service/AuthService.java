package com.civix.service;

import com.civix.dto.request.LoginRequest;
import com.civix.dto.request.RegisterRequest;
import com.civix.dto.response.AuthResponse;
import com.civix.entity.*;
import com.civix.exception.BadRequestException;
import com.civix.exception.DuplicateResourceException;
import com.civix.exception.ResourceNotFoundException;
import com.civix.repository.*;
import com.civix.security.JwtUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final ResidentRepository residentRepository;
    private final SocietyRepository societyRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final AuditLogService auditLogService;

    @Value("${civix.jwt.refresh-expiration}")
    private long refreshExpirationMs;

    @Transactional
    public AuthResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsernameOrEmail(), request.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();

        User user = userRepository.findByUsernameOrEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", userDetails.getUsername()));

        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        Map<String, Object> claims = new HashMap<>();
        List<String> roles = user.getRoles().stream().map(Role::getName).collect(Collectors.toList());
        claims.put("roles", roles);
        claims.put("userId", user.getId());

        String accessToken = jwtUtils.generateToken(user.getUsername(), claims);
        String refreshToken = createRefreshToken(user);

        Long residentId = null;
        Long societyId = null;
        Optional<Resident> residentOpt = residentRepository.findByUserId(user.getId());
        if (residentOpt.isPresent()) {
            residentId = residentOpt.get().getId();
            societyId = residentOpt.get().getSociety().getId();
        }

        auditLogService.log(user, "USER_LOGIN", "User", user.getId(), null, null);

        return AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .userId(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .roles(roles)
                .residentId(residentId)
                .societyId(societyId)
                .build();
    }

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username '" + request.getUsername() + "' is already taken.");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email '" + request.getEmail() + "' is already registered.");
        }

        User user = new User();
        user.setFullName(request.getFullName());
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setPhone(request.getPhone());
        user.setIsActive(true);

        Role residentRole = roleRepository.findByName("ROLE_RESIDENT")
                .orElseThrow(() -> new ResourceNotFoundException("Role ROLE_RESIDENT not found"));
        user.setRoles(new HashSet<>(Set.of(residentRole)));
        userRepository.save(user);

        Society society = societyRepository.findFirstByIsActiveTrue()
                .orElseThrow(() -> new ResourceNotFoundException("No active society found"));

        Resident resident = new Resident();
        resident.setUser(user);
        resident.setSociety(society);
        resident.setUnitNumber(request.getUnitNumber() != null ? request.getUnitNumber() : "TBD");
        resident.setBlockName(request.getBlockName());
        resident.setFloorNumber(request.getFloorNumber());
        if (request.getOccupancyType() != null) {
            resident.setOccupancyType(Resident.OccupancyType.valueOf(request.getOccupancyType()));
        }
        resident.setMoveInDate(LocalDate.now());
        residentRepository.save(resident);

        auditLogService.log(user, "USER_REGISTER", "User", user.getId(), null, user.getEmail());

        LoginRequest loginReq = new LoginRequest();
        loginReq.setUsernameOrEmail(request.getUsername());
        loginReq.setPassword(request.getPassword());
        return login(loginReq);
    }

    @Transactional
    public AuthResponse refreshToken(String refreshTokenStr) {
        RefreshToken refreshToken = refreshTokenRepository.findByToken(refreshTokenStr)
                .orElseThrow(() -> new BadRequestException("Refresh token not found. Please login again."));

        if (refreshToken.isExpired()) {
            refreshTokenRepository.delete(refreshToken);
            throw new BadRequestException("Refresh token has expired. Please login again.");
        }

        User user = refreshToken.getUser();
        Map<String, Object> claims = new HashMap<>();
        List<String> roles = user.getRoles().stream().map(Role::getName).collect(Collectors.toList());
        claims.put("roles", roles);
        claims.put("userId", user.getId());

        String newAccessToken = jwtUtils.generateToken(user.getUsername(), claims);
        String newRefreshToken = createRefreshToken(user);

        Long residentId = null;
        Long societyId = null;
        Optional<Resident> residentOpt = residentRepository.findByUserId(user.getId());
        if (residentOpt.isPresent()) {
            residentId = residentOpt.get().getId();
            societyId = residentOpt.get().getSociety().getId();
        }

        return AuthResponse.builder()
                .accessToken(newAccessToken)
                .refreshToken(newRefreshToken)
                .tokenType("Bearer")
                .userId(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .roles(roles)
                .residentId(residentId)
                .societyId(societyId)
                .build();
    }

    @Transactional
    public void logout(String username) {
        userRepository.findByUsername(username).ifPresent(user -> {
            refreshTokenRepository.deleteByUserId(user.getId());
            auditLogService.log(user, "USER_LOGOUT", "User", user.getId(), null, null);
        });
    }

    private String createRefreshToken(User user) {
        refreshTokenRepository.deleteByUserId(user.getId());
        RefreshToken token = new RefreshToken();
        token.setUser(user);
        token.setToken(UUID.randomUUID().toString());
        token.setExpiryDate(LocalDateTime.now().plusSeconds(refreshExpirationMs / 1000));
        refreshTokenRepository.save(token);
        return token.getToken();
    }
}
