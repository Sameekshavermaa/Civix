-- ============================================================
-- Civix Database Schema
-- AI-Powered Residential Society Management System
-- ============================================================

CREATE DATABASE IF NOT EXISTS civix_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE civix_db;

-- ============================================================
-- ROLES
-- ============================================================
CREATE TABLE roles (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE users (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(100) NOT NULL UNIQUE,
    email           VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(150) NOT NULL,
    phone           VARCHAR(20),
    profile_image   VARCHAR(500),
    is_active       BOOLEAN DEFAULT TRUE,
    email_verified  BOOLEAN DEFAULT FALSE,
    last_login      TIMESTAMP,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- USER ROLES (many-to-many)
-- ============================================================
CREATE TABLE user_roles (
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
);

-- ============================================================
-- SOCIETIES
-- ============================================================
CREATE TABLE societies (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(200) NOT NULL,
    address         TEXT NOT NULL,
    city            VARCHAR(100),
    state           VARCHAR(100),
    pincode         VARCHAR(10),
    total_units     INT DEFAULT 0,
    registration_no VARCHAR(100),
    contact_email   VARCHAR(150),
    contact_phone   VARCHAR(20),
    established_on  DATE,
    logo_url        VARCHAR(500),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- RESIDENTS
-- ============================================================
CREATE TABLE residents (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL UNIQUE,
    society_id      BIGINT NOT NULL,
    unit_number     VARCHAR(20) NOT NULL,
    block_name      VARCHAR(50),
    floor_number    INT,
    occupancy_type  ENUM('OWNER','TENANT') DEFAULT 'OWNER',
    move_in_date    DATE,
    move_out_date   DATE,
    is_active       BOOLEAN DEFAULT TRUE,
    emergency_contact_name  VARCHAR(150),
    emergency_contact_phone VARCHAR(20),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)     REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (society_id)  REFERENCES societies(id) ON DELETE CASCADE
);

-- ============================================================
-- COMPLAINT CATEGORIES
-- ============================================================
CREATE TABLE complaint_categories (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255),
    icon        VARCHAR(100),
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- COMPLAINTS
-- ============================================================
CREATE TABLE complaints (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    complaint_no        VARCHAR(20) NOT NULL UNIQUE,
    resident_id         BIGINT NOT NULL,
    society_id          BIGINT NOT NULL,
    category_id         BIGINT,
    title               VARCHAR(255) NOT NULL,
    description         TEXT NOT NULL,
    status              ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED','REJECTED') DEFAULT 'OPEN',
    priority            ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'MEDIUM',
    assigned_to         BIGINT,
    resolution_comment  TEXT,
    resolved_at         TIMESTAMP,
    ai_category         VARCHAR(100),
    ai_priority         VARCHAR(20),
    ai_duplicate_of     BIGINT,
    ai_confidence       DECIMAL(5,2),
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (resident_id)   REFERENCES residents(id) ON DELETE CASCADE,
    FOREIGN KEY (society_id)    REFERENCES societies(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id)   REFERENCES complaint_categories(id),
    FOREIGN KEY (assigned_to)   REFERENCES users(id),
    FOREIGN KEY (ai_duplicate_of) REFERENCES complaints(id)
);

-- ============================================================
-- COMPLAINT ATTACHMENTS
-- ============================================================
CREATE TABLE complaint_attachments (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    complaint_id    BIGINT NOT NULL,
    file_name       VARCHAR(255) NOT NULL,
    file_path       VARCHAR(500) NOT NULL,
    file_type       VARCHAR(100),
    file_size       BIGINT,
    uploaded_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
);

-- ============================================================
-- COMPLAINT STATUS HISTORY
-- ============================================================
CREATE TABLE complaint_status_history (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    complaint_id    BIGINT NOT NULL,
    changed_by      BIGINT NOT NULL,
    old_status      VARCHAR(30),
    new_status      VARCHAR(30) NOT NULL,
    comment         TEXT,
    changed_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (complaint_id)  REFERENCES complaints(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by)    REFERENCES users(id)
);

-- ============================================================
-- NOTICES
-- ============================================================
CREATE TABLE notices (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    society_id      BIGINT NOT NULL,
    created_by      BIGINT NOT NULL,
    title           VARCHAR(255) NOT NULL,
    content         TEXT NOT NULL,
    notice_type     ENUM('GENERAL','URGENT','EVENT','MAINTENANCE','MEETING') DEFAULT 'GENERAL',
    is_pinned       BOOLEAN DEFAULT FALSE,
    publish_date    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date     TIMESTAMP,
    is_published    BOOLEAN DEFAULT FALSE,
    attachment_url  VARCHAR(500),
    view_count      INT DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (society_id)    REFERENCES societies(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)    REFERENCES users(id)
);

-- ============================================================
-- MAINTENANCE CHARGES
-- ============================================================
CREATE TABLE maintenance_charges (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    society_id      BIGINT NOT NULL,
    charge_month    DATE NOT NULL,
    base_amount     DECIMAL(10,2) NOT NULL,
    late_fee        DECIMAL(10,2) DEFAULT 0.00,
    description     TEXT,
    due_date        DATE NOT NULL,
    created_by      BIGINT NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (society_id)    REFERENCES societies(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)    REFERENCES users(id)
);

-- ============================================================
-- MAINTENANCE RECORDS (per resident)
-- ============================================================
CREATE TABLE maintenance_records (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    maintenance_charge_id BIGINT NOT NULL,
    resident_id         BIGINT NOT NULL,
    amount_due          DECIMAL(10,2) NOT NULL,
    amount_paid         DECIMAL(10,2) DEFAULT 0.00,
    payment_status      ENUM('PENDING','PARTIAL','PAID','OVERDUE','WAIVED') DEFAULT 'PENDING',
    due_date            DATE NOT NULL,
    paid_date           DATE,
    late_fee_applied    DECIMAL(10,2) DEFAULT 0.00,
    notes               TEXT,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (maintenance_charge_id) REFERENCES maintenance_charges(id),
    FOREIGN KEY (resident_id)           REFERENCES residents(id) ON DELETE CASCADE
);

-- ============================================================
-- PAYMENTS
-- ============================================================
CREATE TABLE payments (
    id                      BIGINT AUTO_INCREMENT PRIMARY KEY,
    payment_ref             VARCHAR(50) NOT NULL UNIQUE,
    maintenance_record_id   BIGINT NOT NULL,
    resident_id             BIGINT NOT NULL,
    amount                  DECIMAL(10,2) NOT NULL,
    payment_mode            ENUM('CASH','BANK_TRANSFER','UPI','CHEQUE','ONLINE') DEFAULT 'CASH',
    transaction_id          VARCHAR(150),
    payment_date            DATE NOT NULL,
    remarks                 TEXT,
    recorded_by             BIGINT NOT NULL,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (maintenance_record_id) REFERENCES maintenance_records(id),
    FOREIGN KEY (resident_id)           REFERENCES residents(id),
    FOREIGN KEY (recorded_by)           REFERENCES users(id)
);

-- ============================================================
-- AUDIT LOGS
-- ============================================================
CREATE TABLE audit_logs (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT,
    action          VARCHAR(100) NOT NULL,
    entity_type     VARCHAR(100),
    entity_id       BIGINT,
    old_value       TEXT,
    new_value       TEXT,
    ip_address      VARCHAR(50),
    user_agent      VARCHAR(500),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- REFRESH TOKENS
-- ============================================================
CREATE TABLE refresh_tokens (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT NOT NULL UNIQUE,
    token       VARCHAR(500) NOT NULL UNIQUE,
    expiry_date TIMESTAMP NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_complaints_resident    ON complaints(resident_id);
CREATE INDEX idx_complaints_society     ON complaints(society_id);
CREATE INDEX idx_complaints_status      ON complaints(status);
CREATE INDEX idx_complaints_no          ON complaints(complaint_no);
CREATE INDEX idx_notices_society        ON notices(society_id);
CREATE INDEX idx_notices_published      ON notices(is_published, publish_date);
CREATE INDEX idx_maintenance_resident   ON maintenance_records(resident_id);
CREATE INDEX idx_maintenance_status     ON maintenance_records(payment_status);
CREATE INDEX idx_payments_resident      ON payments(resident_id);
CREATE INDEX idx_audit_user             ON audit_logs(user_id);
CREATE INDEX idx_audit_entity           ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_residents_society      ON residents(society_id);
CREATE INDEX idx_residents_unit         ON residents(unit_number);
