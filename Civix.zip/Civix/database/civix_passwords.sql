-- ============================================================
-- Civix – Fix seed user passwords
-- Run this AFTER the Spring Boot app has started once,
-- OR generate BCrypt hashes using: https://bcrypt-generator.com (rounds=10)
--
-- Admin@123  → $2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
-- Resident@123 (same hash for demo)
-- ============================================================
USE civix_db;

UPDATE users SET password_hash = '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE username IN ('admin', 'rahul.sharma', 'priya.patel', 'amit.kumar', 'sunita.joshi');
