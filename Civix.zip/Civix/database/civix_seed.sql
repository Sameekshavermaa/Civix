-- ============================================================
-- Civix Seed Data
-- ============================================================
USE civix_db;

-- Roles
INSERT INTO roles (name, description) VALUES
('ROLE_ADMIN', 'Society Administrator with full access'),
('ROLE_RESIDENT', 'Resident with limited access');

-- Society
INSERT INTO societies (name, address, city, state, pincode, total_units, registration_no, contact_email, contact_phone, established_on) VALUES
('Green Valley Apartments', '123 Garden Road, Sector 7', 'Bengaluru', 'Karnataka', '560001', 120, 'KA-SOC-2018-001', 'admin@greenvalley.com', '9876543210', '2018-01-15');

-- Admin User (password: Admin@123)
INSERT INTO users (username, email, password_hash, full_name, phone, is_active, email_verified) VALUES
('admin', 'admin@civix.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', 'Society Admin', '9000000001', TRUE, TRUE);

-- Resident Users (password: Resident@123)
INSERT INTO users (username, email, password_hash, full_name, phone, is_active, email_verified) VALUES
('rahul.sharma', 'rahul@example.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', 'Rahul Sharma', '9876543211', TRUE, TRUE),
('priya.patel', 'priya@example.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', 'Priya Patel', '9876543212', TRUE, TRUE),
('amit.kumar', 'amit@example.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', 'Amit Kumar', '9876543213', TRUE, TRUE),
('sunita.joshi', 'sunita@example.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', 'Sunita Joshi', '9876543214', TRUE, TRUE);

-- User Roles
INSERT INTO user_roles (user_id, role_id) VALUES
(1, 1), -- admin -> ROLE_ADMIN
(2, 2), -- rahul -> ROLE_RESIDENT
(3, 2), -- priya -> ROLE_RESIDENT
(4, 2), -- amit -> ROLE_RESIDENT
(5, 2); -- sunita -> ROLE_RESIDENT

-- Residents
INSERT INTO residents (user_id, society_id, unit_number, block_name, floor_number, occupancy_type, move_in_date) VALUES
(2, 1, 'A-101', 'A', 1, 'OWNER',  '2020-03-01'),
(3, 1, 'B-205', 'B', 2, 'TENANT', '2021-06-15'),
(4, 1, 'A-302', 'A', 3, 'OWNER',  '2019-08-10'),
(5, 1, 'C-101', 'C', 1, 'TENANT', '2022-01-20');

-- Complaint Categories
INSERT INTO complaint_categories (name, description, icon) VALUES
('Plumbing',        'Water leakage, pipe issues, drainage problems',  'fa-faucet'),
('Electrical',      'Power outages, wiring issues, switchboard faults','fa-bolt'),
('Lift/Elevator',   'Lift malfunction, maintenance issues',           'fa-elevator'),
('Cleaning',        'Common area cleanliness, garbage collection',    'fa-broom'),
('Security',        'Gate security, CCTV, unauthorized access',       'fa-shield-halved'),
('Parking',         'Parking violations, space allocation issues',    'fa-car'),
('Noise',           'Noise disturbances from neighbors',              'fa-volume-high'),
('Internet',        'WiFi connectivity and internet service issues',  'fa-wifi'),
('Water Supply',    'Water shortage, timing, quality issues',         'fa-droplet'),
('Other',           'Miscellaneous complaints',                       'fa-circle-question');

-- Notices
INSERT INTO notices (society_id, created_by, title, content, notice_type, is_pinned, is_published, publish_date, expiry_date) VALUES
(1, 1, 'Monthly Maintenance Due - June 2024',
 'Dear Residents,\n\nPlease note that the maintenance charges for June 2024 are due by June 10, 2024. The monthly maintenance charge is ₹3,500 per unit.\n\nLate payment will attract a fine of ₹200 per week.\n\nKindly make the payment at the earliest.\n\nThank you,\nManagement',
 'MAINTENANCE', TRUE, TRUE, '2024-06-01 09:00:00', '2024-06-30 23:59:59'),

(1, 1, 'Society General Body Meeting - June 2024',
 'Dear Residents,\n\nYou are cordially invited to the Annual General Body Meeting of Green Valley Apartments.\n\nDate: June 25, 2024\nTime: 6:00 PM\nVenue: Community Hall, Ground Floor\n\nAgenda:\n1. Review of Annual Accounts\n2. Election of Committee Members\n3. Discussion on Upcoming Renovation Plans\n4. Any Other Matter with Permission of Chair\n\nYour presence is requested.\n\nManagement Committee',
 'MEETING', FALSE, TRUE, '2024-06-12 10:00:00', '2024-06-25 18:00:00'),

(1, 1, 'Water Supply Interruption - June 15',
 'Dear Residents,\n\nPlease be informed that water supply will be interrupted on June 15, 2024 from 10:00 AM to 2:00 PM due to maintenance of the overhead tank.\n\nPlease store sufficient water.\n\nWe apologize for the inconvenience.\n\nMaintenance Team',
 'URGENT', TRUE, TRUE, '2024-06-13 08:00:00', '2024-06-15 15:00:00'),

(1, 1, 'CCTV Installation Update',
 'Dear Residents,\n\nWe are pleased to inform you that new CCTV cameras have been installed at all entry/exit points and parking areas. This upgrade enhances the security of our society.\n\nFor any security concerns, please contact the security desk at +91-9000000002.\n\nManagement',
 'GENERAL', FALSE, TRUE, '2024-06-05 11:00:00', NULL);

-- Maintenance Charges
INSERT INTO maintenance_charges (society_id, charge_month, base_amount, late_fee, description, due_date, created_by) VALUES
(1, '2024-04-01', 3500.00, 200.00, 'April 2024 Maintenance - Includes common area upkeep, security, water, and electricity', '2024-04-10', 1),
(1, '2024-05-01', 3500.00, 200.00, 'May 2024 Maintenance - Includes common area upkeep, security, water, and electricity',   '2024-05-10', 1),
(1, '2024-06-01', 3500.00, 200.00, 'June 2024 Maintenance - Includes common area upkeep, security, water, and electricity',  '2024-06-10', 1);

-- Maintenance Records
INSERT INTO maintenance_records (maintenance_charge_id, resident_id, amount_due, amount_paid, payment_status, due_date, paid_date) VALUES
-- April
(1, 1, 3500.00, 3500.00, 'PAID',    '2024-04-10', '2024-04-08'),
(1, 2, 3500.00, 3500.00, 'PAID',    '2024-04-10', '2024-04-09'),
(1, 3, 3500.00, 3500.00, 'PAID',    '2024-04-10', '2024-04-12'),
(1, 4, 3500.00, 0.00,    'OVERDUE', '2024-04-10', NULL),
-- May
(2, 1, 3500.00, 3500.00, 'PAID',    '2024-05-10', '2024-05-07'),
(2, 2, 3500.00, 3500.00, 'PAID',    '2024-05-10', '2024-05-10'),
(2, 3, 3500.00, 1750.00, 'PARTIAL', '2024-05-10', NULL),
(2, 4, 3500.00, 0.00,    'OVERDUE', '2024-05-10', NULL),
-- June
(3, 1, 3500.00, 0.00, 'PENDING', '2024-06-10', NULL),
(3, 2, 3500.00, 0.00, 'PENDING', '2024-06-10', NULL),
(3, 3, 3500.00, 0.00, 'PENDING', '2024-06-10', NULL),
(3, 4, 3500.00, 0.00, 'PENDING', '2024-06-10', NULL);

-- Payments
INSERT INTO payments (payment_ref, maintenance_record_id, resident_id, amount, payment_mode, payment_date, remarks, recorded_by) VALUES
('PAY-APR-001', 1, 1, 3500.00, 'UPI',           '2024-04-08', 'Paid via Google Pay', 1),
('PAY-APR-002', 2, 2, 3500.00, 'BANK_TRANSFER', '2024-04-09', 'NEFT Transfer',       1),
('PAY-APR-003', 3, 3, 3500.00, 'CASH',          '2024-04-12', 'Cash payment',        1),
('PAY-MAY-001', 5, 1, 3500.00, 'UPI',           '2024-05-07', 'Paid via PhonePe',    1),
('PAY-MAY-002', 6, 2, 3500.00, 'UPI',           '2024-05-10', 'Paid via Paytm',      1),
('PAY-MAY-003', 7, 3, 1750.00, 'CASH',          '2024-05-15', 'Partial payment',     1);

-- Sample Complaints
INSERT INTO complaints (complaint_no, resident_id, society_id, category_id, title, description, status, priority, ai_category, ai_priority, ai_confidence) VALUES
('CMP-2024-0001', 1, 1, 1, 'Water leakage in bathroom ceiling',
 'There is a continuous water leakage from the ceiling in my bathroom. Water is dripping from the slab and has damaged the paint and some furniture. This has been ongoing for 3 days.',
 'IN_PROGRESS', 'HIGH', 'Plumbing', 'HIGH', 0.94),

('CMP-2024-0002', 2, 1, 2, 'Electrical short circuit in kitchen',
 'The kitchen switchboard is sparking when I plug in appliances. This is very dangerous and needs immediate attention.',
 'OPEN', 'CRITICAL', 'Electrical', 'CRITICAL', 0.97),

('CMP-2024-0003', 3, 1, 4, 'Garbage not collected from B-block',
 'The garbage from B-block common area has not been collected for 2 days. It is causing a foul smell and hygiene issues.',
 'RESOLVED', 'MEDIUM', 'Cleaning', 'MEDIUM', 0.89),

('CMP-2024-0004', 4, 1, 5, 'CCTV camera near Gate 2 not working',
 'The CCTV camera installed near Gate 2 appears to be non-functional since last week. Security is compromised.',
 'OPEN', 'HIGH', 'Security', 'HIGH', 0.91),

('CMP-2024-0005', 1, 1, 3, 'Elevator making loud noise',
 'The elevator in Block A is making a loud grinding noise. It seems unsafe to use. Please arrange for immediate inspection.',
 'CLOSED', 'HIGH', 'Lift/Elevator', 'HIGH', 0.95);

-- Complaint Status History
INSERT INTO complaint_status_history (complaint_id, changed_by, old_status, new_status, comment) VALUES
(1, 2, NULL,          'OPEN',        'Complaint submitted by resident'),
(1, 1, 'OPEN',        'IN_PROGRESS', 'Assigned to plumber. Will inspect tomorrow morning.'),
(3, 3, NULL,          'OPEN',        'Complaint submitted by resident'),
(3, 1, 'OPEN',        'RESOLVED',    'Garbage cleared. Housekeeping team has been notified to maintain schedule.'),
(5, 1, NULL,          'OPEN',        'Complaint submitted by resident'),
(5, 1, 'OPEN',        'IN_PROGRESS', 'Elevator technician contacted.'),
(5, 1, 'IN_PROGRESS', 'CLOSED',      'Elevator serviced and certified safe by technician.');
